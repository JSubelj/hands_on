package isp.handson;

import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.KeyGenerator;
import javax.crypto.interfaces.DHPublicKey;
import javax.crypto.spec.DHParameterSpec;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import java.nio.ByteBuffer;
import java.security.*;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.LinkedBlockingQueue;

public class HandsOnAssignment {
    public static void main(String[] args) throws Exception {

        final BlockingQueue<byte[]> alice2bob = new LinkedBlockingQueue<>();
        final BlockingQueue<byte[]> bob2alice = new LinkedBlockingQueue<>();

        KeyPairGenerator keygen_A = KeyPairGenerator.getInstance("RSA");
        keygen_A.initialize(2048);
        KeyPair AliceKP = keygen_A.generateKeyPair();
        PublicKey AlicePK = AliceKP.getPublic();

        KeyPairGenerator keygen_B = KeyPairGenerator.getInstance("RSA");
        keygen_B.initialize(2048);
        KeyPair BobKP = keygen_A.generateKeyPair();
        PublicKey BobPK = BobKP.getPublic();


        final Agent alice = new Agent("alice", alice2bob, bob2alice, null, null) {
            @Override
            public void execute() throws Exception {
                // 1.1 Naloga-----------------------
                // Diffie Hellman

                // Alice ustvari svoj DH pub priv keypair
                final KeyPairGenerator Alice_KeyPairGen = KeyPairGenerator.getInstance("DH");
                Alice_KeyPairGen.initialize(2048);
                final KeyPair AliceKeyPair = Alice_KeyPairGen.generateKeyPair();

                // pošlje svoj PubKey bobu ( PubK = g^a)
                outgoing.put(AliceKeyPair.getPublic().getEncoded());
                //print("DH contribute: "+hex(AliceKeyPair.getPublic().getEncoded()));

                // prejme PubKey od boba
                final X509EncodedKeySpec keySpec = new X509EncodedKeySpec(incoming.take());
                final DHPublicKey bobPK = (DHPublicKey) KeyFactory.getInstance("DH").generatePublic(keySpec);

                // Zgenerira session key
                final KeyAgreement dh = KeyAgreement.getInstance("DH");
                dh.init(AliceKeyPair.getPrivate());
                dh.doPhase(bobPK,true);
                final byte[] sessionKey = dh.generateSecret();
                //print("Session Key: "+hex(sessionKey));

                // Ga skrajša na 16B primernih za AES
                SecretKeySpec AESSessionKey = new SecretKeySpec(sessionKey,0,16,"AES"); // key, offset, len, cipher

                // 2.1 naloga --------------------------------

                // Ustvari msg
                String msg = "This is my msg";
                print("msg: "+msg);
                print("hex: "+hex(msg.getBytes()));
                // zgenerira Hash msga
                MessageDigest messageDigestGen = MessageDigest.getInstance("SHA-512");
                byte[] md = messageDigestGen.digest(msg.getBytes());
                print("md: "+hex(md));

                // pošje hash bobu preko varnega kanala
                sendMessage(AESSessionKey,md,outgoing);

                //3. naloga --------------------------------------

                // prejme podpis in timestamp
                byte[] sig_ts=reciveMsg(AESSessionKey,incoming);
                byte[] TS = new byte[8];
                byte[] signature = new byte[sig_ts.length-8];
                System.arraycopy(sig_ts,0,signature,0,sig_ts.length-8);
                System.arraycopy(sig_ts,sig_ts.length-8,TS,0,8);
                long timestamp = bytesToLong(TS);
                print("Signature: "+hex(signature));
                print("Timestamp: "+timestamp);



                // konkatinira TS prej zgeneriranem hashu
                byte[] newPT = concatArray(md,TS);
                print("MD+TS: "+hex(newPT));

                // Preveri če je podpis pravilen
                Signature sigGen = Signature.getInstance("SHA256withRSA");

                sigGen.initVerify(BobPK);
                sigGen.update(newPT);
                if(sigGen.verify(signature)){
                    print("OK");
                }else{
                    print("NOK");
                }

            }
        };


        final Agent bob = new Agent("bob", bob2alice, alice2bob, null, null) {
            @Override
            public void execute() throws Exception {


                // Diffie Hellman
                // get PK from alice
                final X509EncodedKeySpec keySpec = new X509EncodedKeySpec(incoming.take());
                final DHPublicKey alicePk = (DHPublicKey) KeyFactory.getInstance("DH").generatePublic(keySpec);
                // create your own DH key pair
                final DHParameterSpec aliceParameterSpec = alicePk.getParams();
                final KeyPairGenerator bob_keyPairGen = KeyPairGenerator.getInstance("DH");
                bob_keyPairGen.initialize(aliceParameterSpec);
                final KeyPair bob_keyPair = bob_keyPairGen.generateKeyPair();

                // send "PK" to alice ("PK": A = g^a, "SK": a)
                outgoing.put(bob_keyPair.getPublic().getEncoded());
                //print("DH contribute: "+hex(bob_keyPair.getPublic().getEncoded()));

                // Zgenerira session key
                KeyAgreement dh = KeyAgreement.getInstance("DH");
                dh.init(bob_keyPair.getPrivate());
                dh.doPhase(alicePk,true);
                byte[] session_key = dh.generateSecret();
                //print("Session key: "+hex(session_key));

                // ga skrajša na primerno dolžino AES
                SecretKeySpec AESSessionKey = new SecretKeySpec(session_key,0,16,"AES"); // key, offset, len, cipher


                // 2.2 naloga -----------------------------------------------------------------

                // Prejme hash sporočila
                byte[] PT=reciveMsg(AESSessionKey,incoming);
                print("hash: "+hex(PT));

                // vzame timestamp
                long timestamp= System.currentTimeMillis();
                print("Timestamp: "+timestamp);
                // ga pretvori v byte
                byte[] TS=longToBytes(timestamp);
                print("hex: "+hex(TS));

                // concatinira ts hashu
                byte[] newPT = new byte[PT.length + TS.length];
                System.arraycopy(PT, 0, newPT, 0, PT.length);
                System.arraycopy(TS, 0, newPT, PT.length, TS.length);
                print("MD+TS: "+hex(newPT));

                // 2.3 naloga---------------------------------------------
                // Podpiše sporočilo
                Signature sigGen = Signature.getInstance("SHA256withRSA");
                sigGen.initSign(BobKP.getPrivate());
                sigGen.update(newPT);
                byte[] signature = sigGen.sign();
                print("Signature: "+hex(signature));

                // 2.4 naloga -------------------------------------
                // Pošlje podpis in timestamp
                sendMessage(AESSessionKey,concatArray(signature,TS),outgoing);



            }
        };

        alice.start();
        bob.start();
    }

    // 1.2 naloga
    public static void sendMessage(Key key, byte[] msg,BlockingQueue<byte[]> outgoing) throws Exception{
        // Ustvari instanco GCM za secrecy in integrity
        final Cipher cipherGen = Cipher.getInstance("AES/GCM/NoPadding");
        cipherGen.init(Cipher.ENCRYPT_MODE,key);

        // zakriptira plaintext
        byte[] CT = cipherGen.doFinal(msg);
        byte[] IV = cipherGen.getIV();

        // pošlje IV in zakriptiran plaintext
        outgoing.add(IV);
        outgoing.add(CT);
    }

    // 1.2 naloga
    public static byte[] reciveMsg(Key key,BlockingQueue<byte[]> incoming) throws Exception{
        // sprejme IV in CT
        byte[] IV = incoming.take();
        byte[] CT = incoming.take();

        // inicializira GCM
        GCMParameterSpec IvSpec = new GCMParameterSpec(128,IV);
        final Cipher cipherGen = Cipher.getInstance("AES/GCM/NoPadding");
        cipherGen.init(Cipher.DECRYPT_MODE,key,IvSpec);

        // dekriptira prejet CT
        byte[] PT = cipherGen.doFinal(CT);

        return PT;

    }

    public static byte[] concatArray(byte[] a,byte[] b){
        byte[] c = new byte[a.length + b.length];
        System.arraycopy(a, 0, c, 0, a.length);
        System.arraycopy(b, 0, c, a.length, b.length);
        return c;
    }

    public static byte[] longToBytes(long x) {
        ByteBuffer buffer = ByteBuffer.allocate(Long.BYTES);
        buffer.putLong(x);
        return buffer.array();
    }
    public static long bytesToLong(byte[] bytes) {
        ByteBuffer buffer = ByteBuffer.allocate(Long.BYTES);
        buffer.put(bytes);
        buffer.flip();//need flip
        return buffer.getLong();
    }

}
